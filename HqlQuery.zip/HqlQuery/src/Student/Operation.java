package Student;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Operation {
	
 Scanner sc=new Scanner(System.in);
	Student s=new Student();
	public void insert()
	{
		 SessionFactory sf=HibernateUtil.getSessionFactory();
		  Session session=sf.openSession();
		 		
		System.out.println("Enter Name of Student");
		s.setName(sc.next());

		System.out.println("Enter Address of Student");
		s.setAddress(sc.next());
		
		session.save(s);
		session.beginTransaction().commit();
		
	}
	public void display()
	{
		 SessionFactory sf=HibernateUtil.getSessionFactory();
		  Session session=sf.openSession();
		 
		Transaction t=session.beginTransaction();
		String hql="from Student";
		org.hibernate.query.Query q=session.createQuery(hql);
		List<Student>list=q.getResultList();
		for(Student s:list)
		{
			System.out.println(s.getId()+"\n"+s.getName()+"\n"+s.getAddress());
		}
		//session.beginTransaction().commit();
		
}
	public void Delete()
	{
		 SessionFactory sf=HibernateUtil.getSessionFactory();
		  Session session=sf.openSession();
		 
		
		System.out.println("Enter Student Id You want to Delete");
		int a=sc.nextInt();
		String hql="delete from Student s where s.id=?";
		Transaction t=session.beginTransaction();
		org.hibernate.query.Query q=session.createQuery(hql);
			q.setParameter(0, a);
			
			int i=q.executeUpdate();
			if(i!=0)
			{
				System.out.println("Record Deleted....");
			}
			else
			{
				System.out.println("Record not Deleted...");
			}
			//session.beginTransaction().commit();
	}
	public void update()
	{
		 SessionFactory sf=HibernateUtil.getSessionFactory();
		  Session session=sf.openSession();
		
		  System.out.println("Enter ID which You want to update");
		  int i=sc.nextInt();
		  System.out.println("Enter Name U want to Update");
		  String name=sc.next();
		  String hql="update Student set name='"+name+"'where id="+i+" ";
		  Transaction t=session.beginTransaction();
		  org.hibernate.query.Query q=session.createQuery(hql);
		  q.executeUpdate();
		//  session.beginTransaction().commit();
	}
	
	

	
	
	
	
	
	
}
