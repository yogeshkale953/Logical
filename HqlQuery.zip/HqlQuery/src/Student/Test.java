package Student; 

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class Test {
	
public static void main(String[] args) {
	Operation o=new Operation();
	Scanner sc=new Scanner(System.in);
	while(true)
	{
	System.out.println("Press 1 for Insert Record");
	System.out.println("Press 2 for Display All Record");
	System.out.println("Press 3 for Delete");
	System.out.println("Press 4 for Update");
	System.out.println("Press 9 for Exit ");
	System.out.println("Enter Your Choice");
	int choice=sc.nextInt();
	
	switch (choice) {
	case 1:o.insert();
		
		break;
	case 2:o.display();
	break;

	case 3:o.Delete();
	break;
	
	case 4:o.update();
	break;
	
	case 9:System.exit(choice); 
	default:
		break;
	}
	
	
	}
	
	
/*	SessionFactory sf=HibernateUtil.getSessionFactory();
	Session session=sf.openSession();
	Student s=new Student();
s.setAddress("Nimone");
	s.setName("Yogesh");

	session.save(s);
	session.beginTransaction();
	String hql="delete from Student where id=?";
	org.hibernate.query.Query<Student>q=session.createQuery(hql);
	
	q.setParameter(0, 7);
	int i=q.executeUpdate();
session.beginTransaction().commit();
	List<Student>list=q.getResultList();
	for(Student s:list)
	{
		System.out.println(s.getId()+""+s.getName()+""+s.getAddress());
	}
	*/
}
}
