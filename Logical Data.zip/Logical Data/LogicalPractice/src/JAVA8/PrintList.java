package JAVA8;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PrintList {
public static void main(String[] args) {
	List<Integer> list=new ArrayList<>();
	list.add(1);
	list.add(2);
	list.add(5);
	list.add(4);
	list.add(3);
	list.add(7);
//	list.stream().forEach((a)->System.out.println(a));
//	list.stream().filter((a)->a%2==0).forEach((s->System.out.println(s)));
	//list.stream().map((a)->a+5).forEach((a)->System.out.print(a+" "));
	
	Map<Integer, Integer> map=new HashMap<>();
	map.put(1, 1);
	map.put(2, 2);
	map.entrySet().stream().forEach((k)->System.out.println(k.getKey()));
	
	
}
}
