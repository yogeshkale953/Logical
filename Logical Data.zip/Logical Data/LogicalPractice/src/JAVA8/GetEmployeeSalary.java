package JAVA8;

public class GetEmployeeSalary {

	int Id;
	String Name;
	int Salary;

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	
	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getSalary() {
		return Salary;
	}

	public void setSalary(int salary) {
		Salary = salary;
	}

	@Override
	public String toString() {
		return "GetEmployeeSalary [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary + "]";
	}

}
