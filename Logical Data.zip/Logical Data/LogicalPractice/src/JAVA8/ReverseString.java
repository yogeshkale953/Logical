package JAVA8;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ReverseString {
	public static void main(String[] args) {
		String input = "I am at virtual DellEMC Pune office today";
		List l = Pattern.compile(" ").splitAsStream(input).collect(Collectors.toList());
		for (int i = l.size() - 1; i >= 0; i--) {
			System.out.println(l.get(i));
		}

		Arrays.asList(input).stream().map(s -> new StringBuilder(input).reverse().toString())
				.forEach(s -> System.out.println(s));
	}
}
