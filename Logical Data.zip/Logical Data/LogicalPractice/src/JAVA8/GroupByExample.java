package JAVA8;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GroupByExample {
	public static void main(String[] args) {
		String str = "aabccccdddeeeebb";
		List<String> list = Arrays.asList("aabccccdddeeeebb");
		Stream<String> st = Pattern.compile("").splitAsStream(str);
		System.out.println(st);

		for (int i = 0; i < args.length; i++) {
			for (int j = 0; j < args.length; j++) {

			}
		}

		for (String ch : list) {

		}

		list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
				.forEach((k, v) -> System.out.println("key is" + k + "value is" + v));
	}
}
