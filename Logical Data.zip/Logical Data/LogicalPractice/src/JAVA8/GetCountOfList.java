package JAVA8;

import java.util.Arrays;
import java.util.List;

public class GetCountOfList {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		long count = list.stream().count();
		System.out.println("Count is= " + count);

	}
}
