package JAVA8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class GetEmployeeSalaryImp {
	public static void main(String[] args) {
		GetEmployeeSalary g1 = new GetEmployeeSalary();
		g1.setId(1);
		g1.setName("Yogesh");
		g1.setSalary(1200000);
		GetEmployeeSalary g2 = new GetEmployeeSalary();
		g2.setId(2);
		g2.setName("Yogesh Kale");
		g2.setSalary(12000000);
		GetEmployeeSalary g3 = new GetEmployeeSalary();
		g3.setId(3);
		g3.setName("Yogesh Pralhad kale");
		g3.setSalary(12000000);

		List<GetEmployeeSalary> Emplist = new ArrayList<>();

		Emplist.add(g1);
		Emplist.add(g2);
		Emplist.add(g3);
		Optional<GetEmployeeSalary> ges = Emplist.stream()
				.collect(Collectors.minBy(Comparator.comparingInt(GetEmployeeSalary::getSalary)));
		if(ges.isPresent()) {
			System.out.println(ges.get());
		}else {
			System.out.println("ges is not present");
		}

//Optional<GetEmployeeSalary> sal=Emplist.stream().collect(Collectors.maxBy((p1,p2)->Integer.compare(p1.getSalary(), p2.getSalary())).e);
//	System.out.println(sal.toString());
	}

}
