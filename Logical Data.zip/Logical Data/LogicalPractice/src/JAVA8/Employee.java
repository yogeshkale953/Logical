package JAVA8;

public class Employee {
	int id;
	int salary;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public static void main(String[] args) {
		Employee e=new Employee();
		e.setId(1);
		e.setSalary(1000);
		Employee e1=new Employee();
		e.setId(3);
		e.setSalary(2000);
		Employee e2=new Employee();
		e.setId(1);
		e.setSalary(3000);
		Employee e3=new Employee();
		e.setId(2);
		e.setSalary(4000);
		
		
		CheckSalaryInterface csi=(a)->a.getSalary()<2000;
		System.out.println(csi.check(e1));
	}
}
