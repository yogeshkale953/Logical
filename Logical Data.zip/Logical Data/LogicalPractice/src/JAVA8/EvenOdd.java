package JAVA8;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class EvenOdd {
public static void main(String[] args) {
		List<Integer> list=Arrays.asList(1,2,3,4,5,6,7,8);
		list.stream().filter(i->i%2==0).forEach(s->System.out.println(s));

}
}
