package JAVA8;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class CMEInList {
	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(1,2,3,4,5,6,7,8,3);
		
		Iterator<Integer> iterator=list.iterator();
		
		while(iterator.hasNext()) {
			list.set(2, 1);
			System.out.println(iterator.next());
		}
		
	}
}
