package JAVA8;

import java.util.stream.IntStream;

public class FactorialOfNumber {
public static void main(String[] args) {
	
	int num=10,result=1;
	int i=IntStream.rangeClosed(2, num).reduce(1,(x,y)->x*y);
	
	System.out.println(i);
	
	
	
}
}
