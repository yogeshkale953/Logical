package JAVA8;

@FunctionalInterface
public interface CheckSalaryInterface {

	boolean check(Employee e);
}
