package JAVA8;

@FunctionalInterface
public interface Bike {

	 void go();
	
}
