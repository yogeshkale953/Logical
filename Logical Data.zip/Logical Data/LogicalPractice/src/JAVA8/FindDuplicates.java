package JAVA8;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

public class FindDuplicates {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 5, 3, 6);
		HashSet<Integer> hs = new HashSet<>();

		list = list.stream().filter(i -> !hs.add(i)).collect(Collectors.toList());
		System.out.println(list);

	}
}
