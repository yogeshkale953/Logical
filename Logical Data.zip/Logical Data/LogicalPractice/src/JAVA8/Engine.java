package JAVA8;

public class Engine {
	
	public static void main(String[] args) {

		
		Bike b = () -> System.out.println("start");

		b.go();
	}

}
