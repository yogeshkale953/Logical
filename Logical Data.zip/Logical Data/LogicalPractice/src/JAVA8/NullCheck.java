package JAVA8;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class NullCheck {

	public static void main(String[] args) {
		List<Integer> list=Arrays.asList(1,2,3,4,null,5,6,null);
		
		list.stream().forEach(s->Optional.ofNullable(list.get(s)).ifPresent(ss->System.out.println(ss)));
		
		
//		list.stream().forEach(s->System.out.println(s.toString()));
	}
}
