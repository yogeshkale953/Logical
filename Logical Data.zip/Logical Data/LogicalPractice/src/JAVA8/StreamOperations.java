package JAVA8;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class StreamOperations {

	public static void main(String[] args) {
		List<Integer> list=new ArrayList<>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(7);
		list.add(4);
		list.add(5);
		String str="Yogesh Kale Patil";
		List<String>ll=Pattern.compile(" ").splitAsStream(str).collect(Collectors.toList());
		System.out.println(ll);
		long count=list.stream().count();
		boolean b=list.stream().distinct().collect(Collectors.toList()).contains(4);
		//System.out.println(b);
		
		list.stream().filter(i->Collections.frequency(list, i)>1).collect(Collectors.toList()).forEach(i->System.out.println(i));
	}
	
}
