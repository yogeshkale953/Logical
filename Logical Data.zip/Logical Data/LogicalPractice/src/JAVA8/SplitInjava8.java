package JAVA8;

import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class SplitInjava8 {
public static void main(String[] args) {
	
	String name="yogesh kale";
	List<String> list=Pattern.compile(" ").splitAsStream(name).sorted().collect(Collectors.toList());
	System.out.println(list);
}
}
