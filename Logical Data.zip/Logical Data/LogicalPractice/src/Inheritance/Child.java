package Inheritance;

public class Child extends Parent{
	
	String str="Yogesh";
	static int i;
	static {
		float f1[],f2[];
		f1=new float[10];
		f2=f1;
		System.out.println(f2[0]);
		int i=0;
		for(;i<4;i+=2) {
			System.out.println(i);
		}
		System.out.println(i);
	}
	Child(int i){
		
		this.i=i;
	}
	
	
	public void parentM1() {
//	if(i=5) {
//		
//	}
	int a=0;
		for(parentM2();a<0;i++) {
			
		}
		System.out.println("in child m1");
	}
	public void parentM2() {
		System.out.println("in child m2");
	}
	public void M3() {
//		int a=new Child().i;
		System.out.println("In child m3");
	}
	public static void main(String[] args) {
		class a{
			
		}
	}

	
}
