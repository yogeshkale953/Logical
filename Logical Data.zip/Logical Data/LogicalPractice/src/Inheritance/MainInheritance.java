package Inheritance;

import Logical.ProtectedCheck;

public class MainInheritance {
public static void main(String[] args) {
	
	
		ProtectedCheck p=new ProtectedCheck();
//		System.out.println(p.getI());
	
	Parent p1=new Child(1);
//	System.out.println(p1.i);
	
	Base b=new Derive();
	b.Start();
	b.print();
	b.baseMethod();
	Derive d=new Derive();
	d.Start();
	d.print();
	d.deriveMethod();
	d.baseMethod();
	
	
	
	
}
}
