package Inheritance;

public class Parent {
private int i=10;
String str="Yogesh";
public void parentM1() {
	System.out.println("in Parent m1");
}
public void parentM2() {
	System.out.println("in Parent m2");
}

}
