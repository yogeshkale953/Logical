package Inheritance;

public class Base {
	
	int a;
	public void Start() {
		System.out.println("in base start");
	}

	public void print() {

		System.out.println("in base print");
	}
	public void baseMethod() {
		System.out.println("baseMethod");
	}
}
