package Inheritance;

public class Derive extends Base{

	public void Start() {
		System.out.println("in derive start");
	}
	public void print() {

		System.out.println("in derive print");
	}
	public void deriveMethod() {
		System.out.println("deriveMethod");
	}
}
