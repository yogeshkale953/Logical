package CustomSorting;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class MainClass {
	public static void main(String[] args) {

		Employee e1 = new Employee(1, "yogesh");
		Employee e2 = new Employee(2, "Sneha");
		TreeSet<Employee> t = new TreeSet<>(new IdSort());
		t.add(e2);
		t.add(e1);
		for (Employee e : t) {
//		System.out.println(e.getId());

		}
		t.stream().sorted((Employee o1, Employee o2) -> o2.getId() - o1.getId())
				.forEach((e) -> System.out.println(e.getId()));
	}

}
