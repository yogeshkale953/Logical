package Temp1;

public class MainClassForTemp {
public static void main(String[] args) {
	Temp t2 =Temp.getObject();
	System.out.println(t2.hashCode());
	Temp t3 =Temp.getObject();
	System.out.println(t3.hashCode());
}

}
