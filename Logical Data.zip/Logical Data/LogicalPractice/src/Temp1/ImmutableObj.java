package Temp1;

final public class ImmutableObj {
	public String str;

	public ImmutableObj(String s) {
		this.str = s;
	}
	public ImmutableObj getImmutableObj(String s) {
		
		if(this.str==str) {
			return this;
		}
		else {
			return new ImmutableObj(s);
		}
	}
	
	public static void main(String[] args) {
		ImmutableObj i=new ImmutableObj("Yogesh");
		System.out.println(i.hashCode()+"Yogesh");
		ImmutableObj s=i.getImmutableObj("Nilesh");
		System.out.println(s.hashCode());

		ImmutableObj s1=i.getImmutableObj("Nilesh");
		System.out.println(s1.hashCode());

	}
	
}
