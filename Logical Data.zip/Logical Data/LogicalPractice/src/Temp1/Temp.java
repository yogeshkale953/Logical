package Temp1;

public class Temp {
private static Temp tempInstance;

private Temp() {
	
}
public static Temp getObject() {
	if(tempInstance==null) {
		return tempInstance= new Temp();
	}
	else {
		return tempInstance;
	}
}

public static void main(String[] args) {
	Temp t1 =Temp.getObject();

	System.out.println(t1.hashCode());
	Temp t2 =Temp.getObject();
	System.out.println(t2.hashCode());
	Temp t3 =Temp.getObject();
	System.out.println(t3.hashCode());
}
}
