package MapInJava8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MainClass {
public static void main(String[] args) {
	Emplopyee e1=new Emplopyee();
	e1.setId(1);
	e1.setName("Yogesh");
	e1.setSalary(12222);
	
	Emplopyee e2=new Emplopyee();
	e2.setId(2);
	e2.setName("xyz");
	e2.setSalary(123222);
	
	Emplopyee e3=new Emplopyee();
	e3.setId(3);
	e3.setName("Yogeshww");
	e3.setSalary(12222211);
	
	List<Emplopyee>list=new ArrayList<>();
	list.add(e2);
	list.add(e1);
	list.add(e3);

	list.add(e1);
	list.add(e3);
	
	list.stream().map(Emplopyee::getSalary).sorted().distinct().forEach(s->System.out.println(s));
	
	
//	Emplopyee empList=list.stream().collect(Collectors.maxBy(Comparator.comparingInt(Emplopyee::getSalary))).get();
//	System.out.println(empList.getSalary());
	
}
}
