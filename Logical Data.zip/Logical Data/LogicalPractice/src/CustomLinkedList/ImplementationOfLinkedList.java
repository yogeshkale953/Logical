package CustomLinkedList;

public class ImplementationOfLinkedList {

	static class Node {
		private int data;
		private Node Next;

		public Node(int data) {
			this.data = data;
			this.Next = null;
		}
	}

	Node head;

	public void add(int data) {

		Node addElement = new Node(data);
		if (head == null) {
			head = addElement;
			return;
		} else {
			Node temp = head;
			while (temp.Next != null) {
				temp = temp.Next;
			}
			temp.Next = addElement;
		}

	}

	public void getList() {

		Node temp = head;
		while (temp.Next != null ) {
			System.out.println(temp.data);
			temp = temp.Next;
		}
		System.out.println(temp.data);
	}
	public  void deleteAt(int index) {
		Node temp=head;
		Node temp1=head;
		if(temp.data==index) {
			temp.Next=temp1.Next;//todo
		}
		
	}

	public static void main(String[] args) {
		ImplementationOfLinkedList a = new ImplementationOfLinkedList();
		a.add(1);
		a.add(2);
		a.add(22);
		
		a.getList();
		a.deleteAt(2);
	}
}
