package Temp;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class StreamOperations {

	public static void count() {

		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
		System.out.println(list.stream().count());

	}

	public static void getMax() {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
		list.stream().collect(Collectors.maxBy(Integer::compareTo));
	}
	
	public static void getMin() {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
		Optional<Integer> min=list.stream().min(Integer::compareTo);
		System.out.println(min.get());
	}
	public static void additionOfNumbers() {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
	}
	
	public static void main(String[] args) {
		count();
		getMin();
		
	}
}
