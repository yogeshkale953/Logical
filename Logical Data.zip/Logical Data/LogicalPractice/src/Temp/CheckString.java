package Temp;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class CheckString {

	public static void reverseStatement() {
		String input = "I am at virtual DellEMC Pune office today";
		String[] str = input.split(" ");
		StringBuilder s=new StringBuilder(input);
		String ss=s.reverse().toString();
		System.out.println(ss);
//		Arrays.stream(str).sorted(Comparator.reverseOrder()).forEach(s -> System.out.println(s));
//		Arrays.stream(str).
		
		for(int i=str.length-1;i>=0;i--) {
			
			System.out.print(str[i]+" ");
			
		}
	}

	public static void main(String[] args) {
		reverseStatement();
		StringBuffer temp = null;
		String str = "aabccccdddeeeebb";
		char[] ch = str.toCharArray();
		List list = Arrays.asList(ch);
		int count = 0;
		for (int i = 0; i < str.length() - 1; i++) {

			str.charAt(i);

		}

	}
}
