package Temp;

import java.util.ArrayList;
import java.util.List;

public class FunctionalInterfaceImpl {

	public static void main(String[] args) {
		EmployeeForFunctionalInterface e1=new EmployeeForFunctionalInterface(1, "Yogesh", 112233);
		EmployeeForFunctionalInterface e2=new EmployeeForFunctionalInterface(2, "sneha", 1000);
		EmployeeForFunctionalInterface e3=new EmployeeForFunctionalInterface(3, "Navnath", 11111);
		
		List<EmployeeForFunctionalInterface> list=new ArrayList<>();
		list.add(e3);
		list.add(e2);
		list.add(e3);
		
		
		FunctionalInterface f=(s)->(s.getSalary()>2000);
//		FunctionalInterface f=(s)->(s.getSalary()>2000);
		System.out.println(f.checkSalaryGreter(e2));
	}
	
	
}
