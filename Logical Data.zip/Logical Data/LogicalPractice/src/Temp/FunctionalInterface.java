package Temp;


public interface FunctionalInterface {

	abstract boolean checkSalaryGreter(EmployeeForFunctionalInterface e);
}
