package Logical;

public class ValueOfAndtoString {
public static void main(String[] args) {
	LocalPojo l=new LocalPojo();
	l.setId(1);
	l.setName("Yogesh");
	System.out.println(l.toString());
	

	int i=10;
	String s=String.valueOf(i);
	String s1="Yogesh";
	Integer a=Integer.valueOf(s1);
	System.out.println(a.toString());
}
}
