package Logical;

public class PrintArray {

public void sum(int i) {
	while(i<=100) {
	System.out.println(i);	
	i=i+1;
	}
	
}
public static void main(String[] args) {
	PrintArray p=new PrintArray();
	p.sum(1);
}
}
