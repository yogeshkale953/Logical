package Logical;

import java.util.Scanner;

public class Amstrong {
	static int result;

	public static void main(String[] args) {
		System.out.println("pls enter number ");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		int temp = num;
		while (num > 0) {
			int rem = num % 10;
			System.out.println(rem);
			result += rem * rem * rem;
			num = num / 10;

		}
		if (temp == result) {
			System.out.println("Number is amstrong");
		} else {
			System.out.println("number is not amstrong");
		}
	}
}
