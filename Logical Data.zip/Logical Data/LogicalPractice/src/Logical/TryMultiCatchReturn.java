package Logical;

public class TryMultiCatchReturn {
	public static int Check() {
		int i = 10;
		int j = 5;
		try {
			throw new ArithmeticException();
		} catch (ArithmeticException e) {
			System.out.println("in first catch");
			return 5;
		} catch (Exception e) {
			System.out.println("in second catch");
			return 6;
		} finally {
			return 7;
		}

	}

	public static void main(String[] args) {
		int i = Check();
		System.out.println(i);
	}
}
