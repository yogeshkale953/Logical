package Logical;


final class ImmutableClass {

	private static String str;
	public ImmutableClass(String s) {
		this.str=s;
	}
	public ImmutableClass checkImmutable(String s) {
		if(this.str==s) {
			return this;
		}else {
			return new ImmutableClass(s);
		}
	}
}


