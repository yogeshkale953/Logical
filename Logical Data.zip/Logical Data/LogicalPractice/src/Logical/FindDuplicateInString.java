package Logical;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindDuplicateInString {
	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		//String str = "Yogesh Kale Nimone";
//		String[] s = str.split(" ");
//		for (String ss : s) {
//			if(map.containsKey(ss)!=false) {
//				map.put(ss, map.get(ss)+1);
//				
//			}
//			if(map.get(ss)>1) {
//				System.out.println("duplicate value is"+ss);
//			}
//		}
		String str1 = "Yogesh kale kale";
		String[] s = str1.split(" ");
		Map<String, Long> duplicateMap=Arrays.stream(s).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));

		System.out.println(duplicateMap);
		
		//			for(String word:s) {
//				if(map.containsKey(word)==true) {
//					map.put(word, map.get(word)+1);
//				}
//				else {
//					map.put(word, 1);
//				}
//			}
//			map.entrySet().stream().filter(s1->s1.getValue()>1).forEach(st->System.out.println(st));
//			
	}
}
