package Logical;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FindHighestPrimeNumber {
	
	public static boolean checkPrime(int n) {
		
		if(n==0 || n==1) {
			return false;
		}
		for(int i=2;i<=n/2;i++) {
			if(n%i==0)
				return false;
		}
		return true;
		
	}
	
	public static void main(String[] args) {
		int num=100;
	List<Integer>list=new ArrayList<>();
	
//	int max=list.get(highestNumber);
		for(int i=1;i<num;i++) {
		if(checkPrime(i)) {
			list.add(i);
//			System.out.println(i+" ");
			
		}
		System.out.println(list);
		}
		
		Collections.sort(list);
		int highestNumber=list.size()-1;
		
		System.out.println(list.get(highestNumber));
		
		
		System.out.println();
//		System.out.println(list.get(list.indexOf(24)));
		
		
		
	}
}
