package Logical;

public class PrintStringObj {
	String s1,s2;
public static void main(String[] args) {
	
	PrintStringObj p=new PrintStringObj();
	
	System.out.println(p.s1+" "+p.s2);
}
}
