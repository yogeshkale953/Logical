package Logical;

import java.util.Iterator;

public class GetAdditionFromSortedArray {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		int result = 9;
		int length = arr.length - 1;

		int r_index = length;
		int l_index = 0;

		while (l_index < r_index) {
			if (arr[l_index] + arr[r_index] == result) {
				System.out.println(arr[l_index] + " & " + arr[r_index]);
				break;
			}
			if (arr[l_index] + arr[r_index] < result) {
				l_index++;

			} else {
				r_index--;
			}
		}
	}
}
