package Logical;

import java.util.Arrays;

public class BST {
	public static void main(String[] args) {
		int[] arr = { 1, 2, 3, 4, 5, 9, 8, 7, 6 };
		
		int mid= (0-9)/2;
		System.out.println(mid);
		
		
		System.out.println(Arrays.toString(arr));

	}
}
