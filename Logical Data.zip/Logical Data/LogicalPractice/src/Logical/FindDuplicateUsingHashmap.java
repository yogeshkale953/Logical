package Logical;

import java.util.HashMap;
import java.util.Map.Entry;

public class FindDuplicateUsingHashmap {
	public static void main(String[] args) {

		HashMap<Integer, Integer> map = new HashMap<>();
		int[] arr = { 1, 2, 4, 5, 5 };
		for (int a : arr) {
			if (map.get(a) == null) {
				map.put(a, 1);

			} else {
				map.put(a, map.get(a) + 1);
			}
		}
		for (Entry<Integer, Integer> i : map.entrySet()) {
			if (i.getValue() > 1) {
				System.out.println("duplicate Value is =" + i.getKey());
			}
		}
	}
}
