package Logical;

import java.util.Arrays;

public class StringSortInAlphabetical {

	public static String getInOrder() {
		String str="Yogesh";
		String lc=str.toLowerCase();
		char ch[] = lc.toCharArray();

		
		Arrays.sort(ch);
//		String ss=String.valueOf(ch);
		return new String(ch);
	}
	
	public static void main(String[] args) {
		String str = "Yogesh";
		String lowerCaseStr=str.toLowerCase();		
		String ss=getInOrder();
//		System.out.println(ss);
		char ch[] = lowerCaseStr.toCharArray();

		
		char temp;
		for (int i = 0; i < ch.length; i++) {
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[j] < ch[i]) {
					temp = ch[i];
					ch[i] = ch[j];
					ch[j] = temp;
				}
			}
		}
		
		
		System.out.println(ch);
		
	}
}
