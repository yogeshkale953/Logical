package Logical;

public class PrimeNumber {
public static void main(String[] args) {
	int num=99;
	boolean flag=false;
	for(int i=2;i<=num/2;i++) {
		if(num%i==0) {
			flag=true;
			break;
			
		}
	}
	if(flag==false) {
		System.out.println("Number is prime");
	}
	else {
		System.out.println("Number is not prime");
	}
}

}
