package Logical;

public class CheckOverloading {
public static void m1(int a,int b) {
	System.out.println("m1");
}
public static void m1(double a, float b) {
	System.out.println("m2");
}
public static void main(String[] args) {
	m1(0, 0);
	m1(0.0, 0);
}
}
