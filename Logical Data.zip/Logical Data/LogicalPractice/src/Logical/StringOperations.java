package Logical;

public class StringOperations {
	static {
		System.out.println("I'm in static Block");
	}

	{
		System.out.println("im in non static block");
	}
	
	
	public StringOperations() {
		System.out.println("in constructor");
	}
	public static void checkNonDuplicate() {
		String str1 = "Aabbc";
		String str = str1.toLowerCase();

		char[] ch = str.toCharArray();
		for (int i = 0; i < ch.length; i++) {

			if (str.indexOf(ch[i]) == str.lastIndexOf(ch[i])) {
				System.out.println("Duplicate Number is=" + ch[i]);
			} else {
				System.out.println("duplicates are=" + ch[i]);
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("I'm in Main Method");
		String str = "Yogesh";
		StringOperations sss=new StringOperations();
		
//		checkNonDuplicate();
	}
}
