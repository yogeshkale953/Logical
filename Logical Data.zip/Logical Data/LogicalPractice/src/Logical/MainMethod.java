package Logical;

public class MainMethod {

	public static void main( Integer[] ar) {
		System.out.println("in int");
		
	}

	
	public static void main(String[] args) {
	System.out.println("in main");
	
	}
}
