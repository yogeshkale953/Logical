package Logical;

public class WithoutForLoop {

	public static void increase(int i, int j) {
		if(i<j) {
			System.out.println(i);
			increase(i+1, j);
		}
	}
	
	public static void main(String[] args) {
	int i=1;
	
		increase(1, 10);
}
}
