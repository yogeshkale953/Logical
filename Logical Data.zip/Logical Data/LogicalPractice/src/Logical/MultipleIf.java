package Logical;

public class MultipleIf {
public static void main(String[] args) {
	int i=0;
	if(i==0) 
		System.out.println("in first if");
	
	if(i==0) 
		System.out.println("in second if");
		
	
	if(i==1) 
		System.out.println("in third if");
	
	}
}
