package Logical;

public class SuperThisKeywords {
	int i = 0;

	public SuperThisKeywords(int i) {

		this('a');
		System.out.println("in i");
	}

	public SuperThisKeywords(int i, int j) {

		this(1);
		System.out.println("in i,j");
	}

	public SuperThisKeywords(char a) {
		this(1.2);
		System.out.println("in char");
	}

	public SuperThisKeywords(double b) {
		
		this("Yogesh");
		this.m1();
		System.out.println("in double");
	}

	public SuperThisKeywords(String a) {
		super();

	}

	public static void main(String[] args) {
		SuperThisKeywords st = new SuperThisKeywords(0);
	
	}
	public void m1() {
		
	}
}
