package Logical;

import java.util.Objects;

public class OverLoadOwnEquals {
	int id;
	String name;

	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OverLoadOwnEquals other = (OverLoadOwnEquals) obj;
		return id == other.id && Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "OverLoadOwnEquals [id=" + id + ", name=" + name + "]";
	}

	public static void main(String[] args) {

		OverLoadOwnEquals o1 = new OverLoadOwnEquals();
		OverLoadOwnEquals o = new OverLoadOwnEquals();
		boolean a = o.equals("Yoigesg");
		System.out.println(a);

	}
}
