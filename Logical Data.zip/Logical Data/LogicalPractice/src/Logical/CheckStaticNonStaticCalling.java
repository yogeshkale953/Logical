package Logical;

public class CheckStaticNonStaticCalling {

	static  int b=4;
	public static void m2() {
		int a=0;
		System.out.println(b);
	}
	
	public void m1() {
		int a=0;
		
		System.out.println(b);
	}
	
	public static void main(String[] args) {
	
		CheckStaticNonStaticCalling c=new CheckStaticNonStaticCalling();
		c.m1();
}
}
