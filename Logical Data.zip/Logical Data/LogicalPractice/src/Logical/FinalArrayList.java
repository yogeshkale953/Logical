package Logical;

import java.util.ArrayList;

public class FinalArrayList {
	public static void main(String[] args) {

		final ArrayList<Integer> anotherArrayList = new ArrayList<Integer>();

		anotherArrayList.add(1);

		anotherArrayList.add(1);
		anotherArrayList.add(1);

		for(Integer i:anotherArrayList) {
			System.out.println(i);
			
		}
		anotherArrayList.add(2);

		for(Integer i:anotherArrayList) {
			System.out.println(i);
			
		}
		anotherArrayList.set(1, null);
		for(Integer i:anotherArrayList) {
			System.out.println(i);
			
		}
	}
}
