package Logical;

public class StringReverse {
public static void main(String[] args) {
	
	String s="yogesh";
	StringBuilder sb=new StringBuilder(s);
	System.out.println(sb.reverse());
	
	
	
}
}
