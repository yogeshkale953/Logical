package Logical;

import java.util.Scanner;

public class FindSecondOccuranceAndIndex {

	public static void main(String[] args) {
		String str="deemed"; int count=0;
	
	  char[] ch=str.toCharArray();
	  for(int i=0;i<ch.length;i++) {
		  
	  for (int j=i+1;j<ch.length;j++) {
		  if(ch[i]==ch[j]) { 
			 
			  int index = str.indexOf(ch[i], str.indexOf(ch[i]) + 1);
			  System.out.println(ch[i]+" "+index);
		     
	  }
//	  System.out.println(ch[i]+" "+count);
	  
	  }
//	  if(count==2) { int index=str.indexOf(ch[i]); //System.out.println(index); }
	  }
	  }
	  
	 
	/*
	 * public static void main(String[] args) { Scanner scan = new
	 * Scanner(System.in);
	 * 
	 * System.out.print("Enter String: "); String str = scan.nextLine();
	 * System.out.print("Enter a character: "); char ch = scan.next().charAt(0);
	 * 
	 * int index = str.indexOf(ch, str.indexOf(ch) + 1);
	 * 
	 * System.out.println("Index of the second occurrence of " + " character \'" +
	 * ch + "\' is: "+ index); scan.close(); }
	 */
}
