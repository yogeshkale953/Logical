package Logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayToListModify {
public static void main(String[] args) {
	int[] i= {1,2,3,4,5,6};
	List list=new ArrayList<>();
	for(int a:i) {
		System.out.println(a);
		list.add(a);
		
	}
	Arrays.asList(i);
	System.out.println(list);
	
}
	
}
