package Logical;

public class CheckSum {
	int[] arr = { 3, 7, 10, 12, 13, 14, 18, 20, 22 };

	public void check() {
		int j = arr.length - 1;
		int i = 0;
//		System.out.println(arr[i]);
		if (arr[i] + arr[j] > 26) {
			j--;
			if (arr[i] + arr[j] < 26) {
				i++;
				if (arr[i] + arr[j] == 26) {
					System.out.println("Numbers are" + arr[i] + " & " + arr[j]);
				}
				if (arr[i] == arr[j]) {
					System.out.println("number not found");
				}
			}

		}
//		System.out.println(arr[i] + " " + arr[j]);

	}

	public static void main(String[] args) {
		CheckSum c = new CheckSum();
		c.check();
	}
}
