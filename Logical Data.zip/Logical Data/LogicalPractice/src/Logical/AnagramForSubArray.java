package Logical;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class AnagramForSubArray {
	public static void main(String[] args) {
		String[] str = { "cat", "dog", "act", "god" };
		List<List<String>> list = new ArrayList<>();
		Map<String, List<String>> map = new HashMap<>();
		for (String ele : str) {
			char[] ch = ele.toCharArray();
			Arrays.sort(ch);
//			System.out.println(ch);
			String s = String.valueOf(ch);
//			System.out.println(s);
			if (!map.containsKey(s)) {
				map.put(s, new ArrayList<>());
				map.get(s).add(ele);
//				System.out.println(ele);
			}

			for (Entry<String, List<String>> entries : map.entrySet()) {

				System.out.println(entries.getValue());
				
//				list.add(entries.getValue());
			}

		}
//		System.out.println(list);
	}

}
