package Logical;

import java.util.Arrays;
import java.util.Iterator;

public class FirstNonDuplicate {
	public static void main(String[] args) {
		String s="Apple";
		String lowerStr=s.toLowerCase();
		char[] ch=s.toCharArray();
		for(char c:ch) {
			if(s.indexOf(c)==s.lastIndexOf(c)) {
				System.out.println(c);
				break;
			}
		}
	
	}
}
