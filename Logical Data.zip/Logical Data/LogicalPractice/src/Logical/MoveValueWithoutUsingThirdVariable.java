package Logical;

public class MoveValueWithoutUsingThirdVariable {
public static void main(String[] args) {
	
	int a=10;
	int b =20;

	System.out.println("before "+a+" "+b);
	b=b-a;
	a=b+a;
	System.out.println("after "+a+" "+b);
	
}
}
