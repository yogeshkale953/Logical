package Logical;

public class ProtectedCheck {
protected int i=10;
//
//public int getI() {
//	return i;
//}
//
//public void setI(int i) {
//	this.i = i;
//}



}
