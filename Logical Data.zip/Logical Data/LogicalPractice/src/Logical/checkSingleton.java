package Logical;

public class checkSingleton {
	public static void main(String[] args) {
		Singletone s=Singletone.Check();
		System.out.println(s.hashCode());
		Singletone ss=Singletone.Check();
		System.out.println(ss.hashCode());
	}

}
