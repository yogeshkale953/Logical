package Logical;

public class Singletone {

	public static Singletone s;

	private Singletone() {
		s=new Singletone();
	}

	public static Singletone Check() {

		if (s == null) {
		return	s = new Singletone();
		}else {
			return s;
		}
	}
	public static void main(String[] args) {
		ImmutableClass i=new ImmutableClass("abcd");
		ImmutableClass a=i.checkImmutable("abc");
		System.out.println("hashcode Of i "+i.hashCode()+"  "+" hashcode Of a"+a.hashCode());
			ProtectedCheck p=new ProtectedCheck();
			System.out.println(p.i);
	}
}

