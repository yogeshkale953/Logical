package Logical;

public class ReverseStringAsOrder {
	public static void main(String[] args) {
		String s="";
		StringBuffer sb=null;
		String input = "today is thursday";

		String[] word = input.split(" ");
		
		for (int i = 0; i < word.length; i++) {

			 s += word[i]+" ";
			 char[] ch = s.toCharArray();

				for (int j = ch.length - 1; j >= 0; j--) {
					System.out.print(ch[j]);

				}

		}
		
	}
}