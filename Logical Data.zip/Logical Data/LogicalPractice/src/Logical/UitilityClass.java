package Logical;

public class UitilityClass {
	
public static void main(String[] args) {
	ImmutableClass i=new ImmutableClass("yogesh");
	
	System.out.println(i.hashCode());
	
	System.out.println(i.checkImmutable("yogesh").hashCode());
	
	ProtectedCheck p=new ProtectedCheck();
	System.out.println(p.i);
}
}
