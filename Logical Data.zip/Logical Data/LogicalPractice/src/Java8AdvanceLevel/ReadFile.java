package Java8AdvanceLevel;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ReadFile {

	public static void getDataFromCSV() throws IOException {

		FileReader fr = new FileReader("C:\\Users\\kale_y\\Downloads\\Yogesh_Kale_ Timesheet_August_2022_.xlsx");
		BufferedReader br = new BufferedReader(fr);
		String readLi = br.readLine();

		System.out.println(readLi);
	}

	public static void main(String[] args) throws IOException {
		getDataFromCSV();

	}
}
