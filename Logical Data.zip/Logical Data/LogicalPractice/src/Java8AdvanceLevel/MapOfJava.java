package Java8AdvanceLevel;

import java.security.KeyStore.Entry;
import java.util.List;
import java.util.Map;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class MapOfJava {
public static void main(String[] args) {
//	Map.of(K1:"","",
//			k2:)
String list	=Map.of("yogesh", "Kale", "null", "nilu").entrySet().stream()
	.map(entry->String.join("=",
	entry.getKey().toString(),
	entry.getValue().toString())).collect(Collectors.joining(" & "));
	System.out.println(list);
}
}
