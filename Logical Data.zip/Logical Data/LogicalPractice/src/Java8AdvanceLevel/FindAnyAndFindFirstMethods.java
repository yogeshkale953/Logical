package Java8AdvanceLevel;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FindAnyAndFindFirstMethods {
	public static void main(String[] args) {
		List<String> elements = Stream.of("a", "b", "c").filter(element -> element.contains("b"))
				.collect(Collectors.toList());
		Optional<String> anyElement = elements.stream().findAny();
//		System.out.println(anyElement.get());
//		Optional<String> firstElement = elements.stream().findFirst();
//		System.out.println(firstElement.get());
		
		Optional<String> firstElement=Stream.of("a", "b", "c").max((a1,a2)->a1.compareTo(a2));
		System.out.println(firstElement.get());
	}
}
