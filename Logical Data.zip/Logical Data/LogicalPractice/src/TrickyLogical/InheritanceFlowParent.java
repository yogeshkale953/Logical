package TrickyLogical;

public class InheritanceFlowParent {
public InheritanceFlowParent(){
	System.out.println("in parent constructor");
}
public void m1() {
	System.out.println("in parent m1");
}
}
