package TrickyLogical;

public class CheckNullAndZero {
public static void main(String[] args) {
	
	int i=(Integer) null;
	
	if(i<0) {
		System.out.println("i is less than zero");
	}
	else {
		System.out.println("i is greter thatn zero");
	}
}
}
