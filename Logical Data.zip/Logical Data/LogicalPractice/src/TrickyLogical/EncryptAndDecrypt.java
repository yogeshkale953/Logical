package TrickyLogical;

public class EncryptAndDecrypt {

}
