package TrickyLogical;

public class CheckIntern {
	public static void main(String[] args) {
		String s1 = "yogesh";
		s1 += "Kale";

		String s2 = "yogesh";
		s2 += " ";
		s2 += "Kale";

		String s3 = s1.intern();
		String s4=s2.intern();
		System.out.println(s3==s1);
		System.out.println(s4.equals(s2));
				
	}
}
