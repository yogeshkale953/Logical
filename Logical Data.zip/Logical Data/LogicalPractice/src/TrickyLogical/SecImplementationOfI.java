package TrickyLogical;

public class SecImplementationOfI implements InterfaceI {

	int x;

	@Override
	public void cal(int item) {
		x = item / item;
	}

}
