package TrickyLogical;

public class UtilityClass {
	public boolean equals(Object o) {
		
		if(o==null) {
			return false;
		}
		if(this==o) {
			return true;
		}
		
		if(getClass()!=o.getClass()) {
			return false;
		}
		
		
		return false;

	}

	public static void main(String[] args) {

	}
}
