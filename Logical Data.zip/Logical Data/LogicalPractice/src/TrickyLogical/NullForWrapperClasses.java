package TrickyLogical;

public class NullForWrapperClasses {

//	public NullForWrapperClasses(Integer i, Integer j) {
//		System.out.println("in integer");
//	}
//	
//	public NullForWrapperClasses(Float i, Float j) {
//		System.out.println("in float");
//	}
//	
//	public NullForWrapperClasses(Double i, Double j) {
//		System.out.println("in double");
//	}
	
	public void NullForWrapperClasses(Integer i, Integer j) {
		System.out.println("in integer()");
	}
	public void NullForWrapperClasses(Float i, Float j) {
		System.out.println("in Float()");
	}
	
	public static void main(String[] args) {
//	NullForWrapperClasses n=new NullForWrapperClasses(null, null);
}
}

class NullForWrapperClassesChild extends NullForWrapperClasses{
	
	public void checkNull(Float i, Float j) {
		System.out.println("in null check");
	}
	
	@Override
	public void NullForWrapperClasses(Integer i, Integer j) {
		System.out.println("in integer()");
	}
	
	@Override
	public void NullForWrapperClasses(Float i, Float j) {
		System.out.println("in Float()");
	}
}

class main{
	public main() {
		NullForWrapperClasses n=new NullForWrapperClassesChild();
//		n.NullForWrapperClasses(null, null);
		NullForWrapperClassesChild c=new NullForWrapperClassesChild();
		c.checkNull(null, null);
		
	}
}
