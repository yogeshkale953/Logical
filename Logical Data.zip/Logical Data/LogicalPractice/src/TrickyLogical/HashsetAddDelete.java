package TrickyLogical;

import java.util.HashSet;

public class HashsetAddDelete {
public static void main(String[] args) {
	HashSet h=new HashSet<>();
	for(int i=0;i<=100;i++) {
		h.add(i);
		boolean s=h.remove(i-1);
		System.out.println(s);
	}
	System.out.println(h.size());
}
}
