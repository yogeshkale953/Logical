package TrickyLogical;

public class ENUMCheck {
	enum Animnals {
		DOG, Cat, LION;
	}

	public static void main(String[] args) {
		Animnals[] animal = Animnals.values();
//	System.out.println(animal[1]);
	Animnals s=Animnals.DOG;
	System.out.println("value ="+s);
	
	}
}
