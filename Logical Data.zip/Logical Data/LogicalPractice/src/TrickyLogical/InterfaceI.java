package TrickyLogical;

public interface InterfaceI {

	void cal(int item);
}
