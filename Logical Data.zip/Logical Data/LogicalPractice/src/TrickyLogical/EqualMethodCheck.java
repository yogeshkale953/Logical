package TrickyLogical;

public class EqualMethodCheck {
public static void main(String[] args) {

	String s=new String("a");
	String s1=new String("a");
	
	System.out.println(s==s1);
	System.out.println(s.equals(s1));
}
}
