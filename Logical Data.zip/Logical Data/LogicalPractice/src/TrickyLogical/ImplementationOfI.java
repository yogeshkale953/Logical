package TrickyLogical;

public class ImplementationOfI implements InterfaceI{

	int x;
	
	@Override
	public void cal(int item) {
		
		x=item*item;
	}

}
