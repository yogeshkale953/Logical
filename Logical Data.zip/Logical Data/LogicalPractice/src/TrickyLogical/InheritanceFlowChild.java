package TrickyLogical;

public class InheritanceFlowChild {
public InheritanceFlowChild() {
	System.out.println("in child constructor");
}
public void m1() {
	System.out.println("in child m1");
}
public static void main(String[] args) {
	InheritanceFlowChild h=new InheritanceFlowChild();
	h.m1();
}
}
