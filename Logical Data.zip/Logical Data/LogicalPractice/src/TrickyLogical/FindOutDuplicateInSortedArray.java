package TrickyLogical;

public class FindOutDuplicateInSortedArray {

	public static boolean check() {
		int[] arr = { 1, 2, 3, 4, 5, 6,6 };
		int length = arr.length - 1;

		int maxEle = arr[length];
		int temp = 1;

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] == arr[i + 1]) {
				System.out.println("Array Contains Duplicate ele");

				return false;
			} else {
				System.out.println("in else");
				
			}
//			return true;
		}
		return true;

//			if (temp == arr[i]) {
//				temp++;
//			} else {
//				
//			}
//		}
//		return false;
	}

	public static void main(String[] args) {
		check();
	}
}
