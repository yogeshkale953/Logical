package TrickyLogical;

public class ReverseStringWithoutUsingInbuildFunction {
public static void main(String[] args) {
	String str="Yogesh";
	char[] ch = str.toCharArray();
	StringBuffer sf = new StringBuffer();
	String str1="";
	for(int i=ch.length-1;i>=0;i--){
		
		char a=ch[i];
		sf.append(a);

	}
	str1=new String(sf);
		System.out.println(str1);
}
}
