package TrickyLogical;

public class TestInterfaceI {
public static void main(String[] args) {
	ImplementationOfI im1=new ImplementationOfI();
	im1.x=0;
	
	SecImplementationOfI im2=new SecImplementationOfI();
	im2.x=0;
	
	im1.cal(1);
	im2.cal(2);
	System.out.println(im1.x+" "+im2.x);
	
}
}
