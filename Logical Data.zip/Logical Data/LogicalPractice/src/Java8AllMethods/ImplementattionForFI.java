package Java8AllMethods;

public class ImplementattionForFI implements FunctionInterfaces{

	public static void main(String[] args) {
		
		
		ImplementattionForFI a=new ImplementattionForFI();
		a.m2();
	
	
	}
}
