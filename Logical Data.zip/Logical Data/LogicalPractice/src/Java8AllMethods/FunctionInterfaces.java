package Java8AllMethods;

public interface FunctionInterfaces {

	static void m1() {
		System.out.println("static");
	}
	default void m2() {
		System.out.println("default");
	}
}
