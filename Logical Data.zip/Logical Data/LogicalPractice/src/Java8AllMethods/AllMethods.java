package Java8AllMethods;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import CustomSorting.Employee;

import java.util.*;

public class AllMethods {

	public static void getCount() {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		long count = list.stream().count();
		System.out.println("Count is= " + count);

	}

	public static void sortArrayAsAssending() {
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		list.stream().sorted().forEach(s -> System.out.println(s));
	}

	private static void customSortingAarray() {

		List<Integer> list = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		list.stream().sorted(Comparator.reverseOrder()).forEach(s -> System.out.println(s));

	}

	public static void getMinimumElementFromArray() {

		List<Integer> list = Arrays.asList();
		Optional minValue = list.stream().sorted().collect(Collectors.minBy(Integer::compareTo));
		if (minValue.isPresent()) {
			System.out.println("Min Value is = " + minValue.get());
		} else {
			System.out.println("Min Value is not present");
		}

	}

	public static void getMaxElement() {
		List<Integer> listInt = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		Optional maxValue = listInt.stream().collect(Collectors.maxBy(Integer::compareTo));
		System.out.println(maxValue.get());

		List<String> listString = Arrays.asList("yogesh", "Kale", "Nimone");
		listString.stream().sorted(Comparator.reverseOrder()).forEach(s -> System.out.println(s));
	}

	public static void getMaxMinFromArray() {

		int[] arr = { 1, 2, 3, 4, 5 };
		int a = Arrays.stream(arr).min().getAsInt();
		System.out.println(a);
		int max = Arrays.stream(arr).max().getAsInt();
		System.out.println(max);
	}

	public static void getEvenOdd() {
		int[] arr = { 1, 2, 3, 4, 5 };
		Arrays.stream(arr).filter(s -> s % 2 != 0).forEach(s -> System.out.println(s));
	}

	public static void getDistinct() {
		List<Integer> listInt = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		listInt.stream().distinct().forEach(s -> System.out.println(s));
	}

	public static void getSalaryOfEmpAsAssending() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);

		listEmp.stream().sorted(Comparator.comparingInt(EmployeeUtil::getSalary))
				.forEach(s -> System.out.println("Employees according to salary= " + s.getSalary()));

	}

	public static void getMinSalaryOfEmp() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);

		EmployeeUtil minSalary = listEmp.stream().min(Comparator.comparingInt(EmployeeUtil::getSalary)).get();
		System.out.println("Min Salary of emp= " + minSalary.getName() + " " + minSalary.getSalary());
	}

	public static void getEmpNameAsAlphabatic() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);

		listEmp.stream().sorted((a1, a2) -> a1.getName().compareTo(a2.getName()));
	}

	public static void getEmpHighestSalary() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);

		EmployeeUtil empMaxSalary = listEmp.stream().max(Comparator.comparingLong(EmployeeUtil::getSalary)).get();
		System.out.println(empMaxSalary);
	}

	public static void increaseEverySalByTwo() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
		listEmp.stream().map(EmployeeUtil::getSalary).mapToInt(s -> s * 2).forEach(s -> System.out.println(s));
//		int sal = listEmp.stream().map(EmployeeUtil::getSalary).reduce((s1, s2) -> s1 + s2).get();
//		System.out.println(sal);
	}

	public static void getSquarOfEachEle() {

		List<Integer> listInt = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		listInt.stream().map(s -> s * s).forEach(s -> System.out.println(s));
	}

	public static void applyLimit() {
		List<Integer> listInt = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		listInt.stream().limit(3).forEach(s -> System.out.println(s));
	}

	public static void checkStatistic() {

		List<Integer> listInt = Arrays.asList(1, 2, 3, 4, 9, 8, 7, 6, 5, 4, 3);
		IntSummaryStatistics stat = listInt.stream().mapToInt((s) -> s).summaryStatistics();

		System.out.println("Average is " + stat.getAverage());
		System.out.println("Count is " + stat.getCount());
		System.out.println("Max is " + stat.getMax());
		System.out.println("Min is " + stat.getMin());
		System.out.println("Sum is " + stat.getSum());

	}

	public static void getMinEmpNameAsAlphabatic() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
		Optional smallName = listEmp.stream().map(EmployeeUtil::getName).min((a1, a2) -> a1.compareTo(a2));
		System.out.println(smallName.get());
	}

	public static void getGroupingByName() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
		List<Object> list = new ArrayList<>();
		String s = "aabccccdddeeeebb";

		char[] str = s.toCharArray();
		for (char ch : str) {
			list.add(ch);
		}
		Map<Object, Long> a = list.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		a.forEach((k, v) -> System.out.print(k + "" + v));

		// String st = Arrays.stream(s.split("(?<=(.))(?!\\1)"))
//
//				.map(str -> str.charAt(0) + "" + str.length()).collect(Collectors.joining());
//		listEmp.stream().collect(Collectors.groupingBy(EmployeeUtil::getName,Collectors.counting())).forEach((k,v)->System.out.println(k+ " " +v));
//		System.out.println(st);

		StringBuffer sb1 = new StringBuffer("Deepak");
		StringBuffer sb2 = new StringBuffer("Deepak");

		System.out.println(sb1 == sb2);

		System.out.println(sb1.equals(sb2));
	}

	public static void getOnlyAddress() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Nimone", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);

		listEmp.stream().map(EmployeeUtil::getSalary).mapToInt(s -> s * 2).forEach(s -> System.out.println(s));
//		System.out.println(a);

		// EmployeeUtil
		// min=listEmp.stream().min(Comparator.comparingLong(EmployeeUtil::getSalary)).get();
//		System.out.println(min.getName()+" "+min.getSalary());
//		listEmp.stream().map(EmployeeUtil::getAddress).forEach(s->System.out.println(s));
	}

	public static void GroupingByAndCounting() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Pune", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
		Map<Object, Long> byAddress = listEmp.stream()
				.collect(Collectors.groupingBy(EmployeeUtil::getAddress, Collectors.counting()));

		byAddress.entrySet().forEach(s -> System.out.println(s.getKey() + " " + s.getValue()));

	}

	public static void getRepeatedCharCount() {

		String str = "apple";
		List<Character> list = str.chars().mapToObj(x -> (char) x).collect(Collectors.toList());

		Map<Object, Long> charAndCount = list.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
//	charAndCount.entrySet().stream().
	}

	public static void getSalaryGreaterThanAmount() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Pune", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
		listEmp.stream().filter(e -> e.getSalary() > 20000).forEach(s -> System.out.println(s.getName()));
	}

	public static void getChunkSizeElement() {

		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15);
		int chunk = 5;
		AtomicInteger counter = new AtomicInteger();
//		automaticIntege	 counter = new aut
//		auto
		Collection<List<Integer>> l = numbers.stream()
				.collect(Collectors.groupingBy(i -> counter.getAndIncrement() / chunk)).values();
		System.out.println(l);
	}

	public static void getOddMax() {
		List<Integer> list = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9);
		Optional<Integer> d = list.stream().filter(s -> s % 2 != 0).max(Integer::compareTo);
		System.out.println(d.get());
	}

	public static void addPrefix() {
		List<String> list = List.of("yogesh", "navnath", "shrikant");

		List l = list.stream().map(s -> "Mr " + s).collect(Collectors.toList());
		System.out.println(l);

	}

	public static void findDuplicateUsingNameAndAddress() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Pune", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
//		listEmp.stream().collect(null)
	}

	public static void findName() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Pune", 100000);
		EmployeeUtil e2 = new EmployeeUtil(2, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(3, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(4, "Abc", "Mumbai", 200000);
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
//		listEmp.stream().map(s -> s.getName().equals("Yogesh")).forEach(s -> System.out.println(s));

		EmployeeUtil u = listEmp.stream().filter(s -> s.getName().equals("Yogesh")).findAny().get();

		Boolean u1 = listEmp.stream().map(s -> s.getName().equals("Yogesh")).findAny().get();
		System.out.println(u);

	}

	// ***Terminal Operations***
	// findAny & findFirst
	public static void findAnyMethod() {
		// FindAny will return any from list and findFirst will return only first one.
		Optional<String> anyElement = List.of("yogesh", "python", "cpp", "java", "python").stream().findAny();
		System.out.println(anyElement.get());
		Optional<String> firstElement = List.of("yogesh", "python", "cpp", "java", "python").stream().findFirst();
		System.out.println(firstElement.get());
	}

	// anyMatch
	public static void anyMatchMethod() {
		// anyMatch will return true value if any one value match.
		boolean value = List.of("yogesh", "python", "cpp", "java", "python").stream().anyMatch(s -> {
			return s.startsWith("y");
		});
		System.out.println(value);

		// allMatch will check all values are start with if one is not then it return
		// false
		boolean valueOfAllMatch = List.of("yogesh", "python", "cpp", "java", "python").stream().allMatch(s -> {
			return s.startsWith("y");
		});
		System.out.println(valueOfAllMatch);

		// nonMatch will check all the element and if any element match then it will
		// return false

		boolean valueNonMatch = List.of("yogesh", "python", "cpp", "java", "python").stream().noneMatch(s -> {
			return s.startsWith("y");
		});
		System.out.println(valueNonMatch);

	}

	public static void concateInStream() {
		int[] int1 = { 1, 2, 3, 4 };
		int[] int2 = { 5, 6, 7, 8, 9 };

		Stream stream1 = List.of("monday", "tuesday", "wednesday").stream();
		Stream stream2 = List.of("thusday", "friday", "saturday", "sunday").stream();
		Object a = Stream.concat(stream1, stream2).sorted().collect(Collectors.toList());
		System.out.println(a);
	}

	public static void getDuplicateFromString() {
		String s = List.of("xyz", "xyz xyz", "abcabc").stream().collect(Collectors.joining("  "));

		System.out.println(s);
		Map<String, Long> str = Pattern.compile("  ").splitAsStream(s)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		// String aa=str.map(a->a).findAny().orElse("");
		System.out.println(str);

	}

	public static void ifIdDuplicateThenSortByName() {
		EmployeeUtil e1 = new EmployeeUtil(1, "Yogesh", "Pune", 100000);
		EmployeeUtil e2 = new EmployeeUtil(1, "Xyz", "Nagar", 20000);
		EmployeeUtil e3 = new EmployeeUtil(2, "Pqr", "Pune", 30000);
		EmployeeUtil e4 = new EmployeeUtil(2, "Yogesh", "Banglore", 200000);
		Comparator<EmployeeUtil> byName = (emp1, emp2) -> emp1.getName().compareTo(emp2.getName());
		Comparator<EmployeeUtil> byAddress = (emp1, emp2) -> emp1.getAddress().compareTo(emp2.getAddress());
		List<EmployeeUtil> listEmp = new ArrayList<>();
		listEmp.add(e1);
		listEmp.add(e2);
		listEmp.add(e3);
		listEmp.add(e4);
//		List<Person> list = new ArrayList<Person>();
		listEmp.stream().sorted(byName.thenComparing(byAddress))
				.forEach(s -> System.out.println(s.getName() + " " + s.getAddress()));
	}

	public static void main(String[] args) {

//		getCount();
//		sortArrayAsAssending();
//		customSortingAarray();
//		getMinimumElementFromArray();?
//		getMaxElement();
//		getMaxMinFromArray();
//		getDistinct();
//		getMinSalaryOfEmp();
//		getSalaryOfEmpAsAssending();
//		getEmpNameAsAlphabatic();
//		getEmpHighestSalary();
//		getEvenOdd();
//		getSquarOfEachEle();
//		increaseEverySalByTwo();
//		applyLimit();
//		checkStatistic();
//		getMinEmpNameAsAlphabatic();
//		getGroupingByName();
//		getOnlyAddress();
//		GroupingByAndCounting();
//		getRepeatedCharCount();
//		getSalaryGreaterThanAmount();
//		getChunkSizeElement();
//		getOddMax();
//		addPrefix();
//		findName();
//		findAnyMethod();
//		anyMatchMethod();
//		concateInStream();
//		getDuplicateFromString();
		ifIdDuplicateThenSortByName();

	}

}
