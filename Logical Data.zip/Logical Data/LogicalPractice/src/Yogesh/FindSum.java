package Yogesh;

public class FindSum {

	public void checkSum() {
		int[] arr = { 3, 7, 10, 12, 13, 14, 18, 20, 22 };

		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] + arr[j] == 26) {
					System.out.println(arr[i] + "  " + arr[j]);
				}
			}
		}

	}

	int maxNum;

	public void FindLargest() {
		int[] arr = { 3, 10, 8, 12, 4, 16, 13, 22, 20 };

		int count = 0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				int Num = Math.max(arr[i], arr[j]);
				
				System.out.println(Num);
				for (int k = j + 1; k < arr.length; k++) {
					maxNum = Math.max(Num, arr[k]);
					System.out.println( maxNum);
				}
			}

		}

	}

	public static void main(String[] args) {
		FindSum f = new FindSum();
		f.checkSum();
		f.FindLargest();
	}

}
