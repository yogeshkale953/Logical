package Yogesh;

public class Employee  implements Comparable{
	String name;
	int priority;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	@Override
	public int compareTo(Object o) {
		Employee e=(Employee) o;
		// TODO Auto-generated method stub
		return this.getPriority()-e.getPriority();
	}

}
