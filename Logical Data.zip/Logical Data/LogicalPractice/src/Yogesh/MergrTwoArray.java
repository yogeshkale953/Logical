package Yogesh;

import java.util.Arrays;

public class MergrTwoArray {
	public static void main(String[] args) {
		int[] arr1 = { 1, 2, 3, 45, 6 };

		int[] arr2 = { 1, 2, 4, 6, 8 };

		int size1=arr1.length;
		int size2=arr2.length;
		int size3=size1+size2;
		int[] arr3=new int[size3];
	
		int temp=0;
		int a=0;
		int b=0;
		
		while(a<size1) {
			arr3[temp++]=arr1[a++];
		}
		while(b<size2) {
			arr3[temp++]=arr2[b++];
		}
		Arrays.sort(arr3);		
		for(int z:arr3) {
			System.out.println(z);
		}
		

		
	}
}
