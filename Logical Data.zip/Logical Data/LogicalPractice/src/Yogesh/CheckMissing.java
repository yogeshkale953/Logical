package Yogesh;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class CheckMissing {

	public void findMissingUsingFormula(int[] arr, int Count) {

		int expSum = Count * ((Count + 1) / 2);
		int actualSum = 0;
		for (int i : arr) {
			actualSum += i;
		}
		int missingNumber=expSum-actualSum;
		System.out.println("missing number is= "+missingNumber);

	}

	public void missingNumber() {
		List<Integer> list = new ArrayList<>();
		int[] arr = { 11, 12, 13, 14, 15, 16, 17, 19, 20 };

		int expSum = 20;

		int initialValue = arr[0];
		int length = arr.length;
		int highestNumber = arr[length - 1];
		for (Integer ele : arr) {
			list.add(ele);
		}
		for (int i = initialValue; i < highestNumber; i++) {
			if (list.contains(i) == false) {
				System.out.println("missing number is= " + i);
			}
		}
	}

	public void check() {
		int[] arr = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 21 };

		int temp = arr[0];
		int length = arr.length;
		for (int i = 0; i <= length - 1; i++) {
			if (temp != arr[i]) {
				System.out.println("Missing element is=" + temp);
			}
			temp++;
		}

	}

	public void addItemAsPriority() {

		Employee e = new Employee();
		e.setName("abc");
		e.setPriority(2);
		Employee e1 = new Employee();
		e1.setName("abcd");
		e1.setPriority(1);
		Employee e2 = new Employee();
		e2.setName("abcde");
		e2.setPriority(4);
		Employee e3 = new Employee();
		e3.setName("abcz");
		e3.setPriority(3);

		TreeSet<Employee> t = new TreeSet<>();

		t.add(e);
		t.add(e1);
		t.add(e2);
		t.add(e3);

		for (Employee emp : t) {
//			System.out.println(emp.getName() + " Priority is " + emp.getPriority());
		}

		int temp = 0;
		TreeMap<Character, Integer> map1 = new TreeMap<>();
		map1.put('a', 5);
		map1.put('b', 2);
		map1.put('c', 8);
		map1.put('d', 4);

//		map1.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
//		map1.entrySet().stream()
//		.sorted(Map.Entry.comparingByValue(Comparator.comparingInt(Employee::getPriority).reversed()));

	}

	public static void main(String[] args) {

		CheckMissing c = new CheckMissing();
//		c.missingNumber();
//		c.check();
//		c.addItemAsPriority();
		int[] arr = { 11, 12, 13, 14, 15, 16, 17, 18, 19, 21};
		c.findMissingUsingFormula(arr,21);
	}
}
