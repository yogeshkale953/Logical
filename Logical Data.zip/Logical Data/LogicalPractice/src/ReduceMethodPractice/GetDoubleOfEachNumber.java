package ReduceMethodPractice;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import MapInJava8.Emplopyee;

public class GetDoubleOfEachNumber {
	public static void main(String[] args) {
		Set<Integer> setInt = new HashSet<>();
		List<Integer> Intlist = Arrays.asList(1, 2, 3, 4, 5, 6, 3, 2, 2);
//		Intlist.stream().distinct().forEach(s->System.out.println(s));
//		Intlist.stream().filter(s->!setInt.add(s)).forEach(s->System.out.println(s));;

		Long count=Intlist.stream().sorted().count();
		System.out.println(count);
		
		
		Intlist.stream().map(s -> s * s).forEach(s -> System.out.println(s));
		int value = Intlist.stream().distinct().map(s -> s * s).reduce((a, b) -> a + b).get();
		System.out.println(value);

	}
}
