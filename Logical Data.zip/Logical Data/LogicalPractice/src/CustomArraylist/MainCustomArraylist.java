package CustomArraylist;

public class MainCustomArraylist {
	public static void main(String[] args) {
		ArraylistCustom a=new ArraylistCustom();
		a.addElement(5);
		a.addElement(1);
		a.addElement(3);
		a.addElement(4);
		a.addElement(5);
		a.addElement(9);
		//a.addElement(null);
		a.addElement('a');
		//a.addElement(1.100);
		a.getElement();
		int i=a.size;
		System.out.println("size is: "+i);
	}

}
