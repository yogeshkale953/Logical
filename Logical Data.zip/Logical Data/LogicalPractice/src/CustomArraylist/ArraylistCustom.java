package CustomArraylist;

public class ArraylistCustom {
	int arr[];
	int size;
	int capacity;

	ArraylistCustom() {
		capacity = 10;
		size = 0;
		arr = new int[capacity];
	}
	
	public void addElement(int o) {
		arr[size++]=o;
	}
	public void getElement() {
		
		for(int i=0;i<size;i++)
		
		
		System.out.println(arr[i]);
		
		
		
		
	}
	
	public int getSize() {
		
		return size;
		
	}

}
