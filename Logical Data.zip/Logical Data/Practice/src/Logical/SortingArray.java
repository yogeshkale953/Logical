//package Logical;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import javax.swing.border.EmptyBorder;
//
//public class SortingArray {
//	public static void main(String[] args) {
//		int temp;
//		int[] intArray = { 8, 4, 2, 9, 1, 34, 56, 98, 79 };
//		for (int i = 0; i < intArray.length; i++) {
//			for (int j = i + 1; j <= intArray.length; j++) {
//				if (intArray[i] > intArray[j]) {
//					temp = intArray[i];
//					intArray[i] = intArray[j];
//					intArray[j] = temp;
//				}
//
//			}
//
//		}
//		
//
//	}
//	
//	
//	public void ChechDigit() {
//		List<Integer> list=Arrays.asList(1,2,3,13,20,21,22);
//		
//		
////		employee e=Optional.ofNullable(e->employee.getID);
//		if(e.isPresent) {
//			System.out.println(e.get());
//		}
//		
//		Runnable r=()->{System.out.println("We are in Runnable");};
//		
//
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//}
