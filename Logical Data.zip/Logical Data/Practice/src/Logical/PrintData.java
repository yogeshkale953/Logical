package Logical;

public class PrintData {
public static void main(String[] args) {
int i=2;
int temp=i;
while(i<=temp) {
	System.out.print(i);
	i=i+2;
}



//for(i=2;i<=100;i++) {
//	
//	System.out.print(i);
//	
//}


}
}
