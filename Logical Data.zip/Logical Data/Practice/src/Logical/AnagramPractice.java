package Logical;

import java.util.Arrays;

public class AnagramPractice {

	
	public static void checkAnagram() {
		String str1="Race";
		String str2="Care1";
		
		String lowerStr1=str1.toLowerCase();

		String lowerStr2= str2.toLowerCase();
		
		if(lowerStr1.length()==lowerStr2.length()) {
			char[] ch1 =lowerStr1.toCharArray();
			char[] ch2=lowerStr2.toCharArray();
			Arrays.sort(ch1);
			Arrays.sort(ch2);
		boolean result=	Arrays.equals(ch1, ch2);
		if(result==true) {
			System.out.println("String's are anagram");
		}
		}
		else {
			System.out.println("Not Anagram");
		}
		}
	
	public static void main(String[] args) {
	checkAnagram();
	
	
	
}
}
