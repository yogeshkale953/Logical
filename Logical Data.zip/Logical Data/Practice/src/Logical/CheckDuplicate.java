package Logical;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CheckDuplicate {
	public static void main(String[] args) {
		String s = List.of("abc", "pqr", "abc", "abc world", "pqr pqr").stream().collect(Collectors.joining("  "));
		System.out.println(s);
		Stream<String> mapOfSplit = Pattern.compile("  ").splitAsStream(s);

		Map<String, Long> map=mapOfSplit.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		map.forEach((k,v)->System.out.println(k +" "+v));
		//		map.collect(Collectors.groupingBy(Function.identity()),Collectors.counting());

//Pattern.compile(" ").splitAsStream(list);		
//		Stream<Object> a = list.stream().map(s -> s.split(" "));
//		a.forEach(null);
//		Map<Object, Long> count = a.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

	}

}
