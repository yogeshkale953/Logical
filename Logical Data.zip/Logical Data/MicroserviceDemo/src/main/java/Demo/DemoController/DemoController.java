package Demo.DemoController;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import Demo.Model.Student;

@RestController
public class DemoController {

	Student student = new Student();

	@GetMapping(value = "/custom")
	public String test() {
		System.out.println("in test");
		return "Done";
	}

	@GetMapping("/")
	public String welcome() {
		return "Welcome to my world";

	}
}
