package Demo.Model;

import lombok.Data;

@Data
public class Student {
	int Number;
	String Name;

}
