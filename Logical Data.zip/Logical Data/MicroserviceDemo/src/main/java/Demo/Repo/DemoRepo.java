package Demo.Repo;

import java.util.List;

import org.springframework.stereotype.Repository;

import Demo.Model.User;

@Repository
public interface DemoRepo {
	
	
	
	

}
