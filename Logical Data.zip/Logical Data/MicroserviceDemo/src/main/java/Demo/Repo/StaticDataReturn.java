package Demo.Repo;

import java.util.ArrayList;
import java.util.List;

import Demo.Model.User;

public class StaticDataReturn {
	public List<User> getUsers() {

		User user1 = new User(1, "Yogesh", "yogeshkale", "ykpatil");
		User user2 = new User(2, "xyz", "xyz", null);
		User uer3 = new User(3, "pqr", "pqr", "pqr");
		User user4 = new User(4, "abc", "abc", "abc");
		List<User> list = new ArrayList<User>();
		list.add(user1);
		list.add(user2);
		list.add(uer3);
		list.add(user4);

		return list;

	}
}
