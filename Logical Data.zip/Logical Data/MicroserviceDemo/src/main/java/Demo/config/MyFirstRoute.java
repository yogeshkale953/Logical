package Demo.config;

import java.time.LocalDateTime;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//@Component
public class MyFirstRoute extends RouteBuilder {

	@Autowired
	FindDateAndTime getDateAndTime;
	
	@Override
	public void configure() throws Exception {

		from("timer:first-timer")
		//.log("${body}")
		//.transform().constant("Time is= "+ LocalDateTime.now())
		.bean(getDateAndTime)
		.to("log:first-timer");

	}

 }