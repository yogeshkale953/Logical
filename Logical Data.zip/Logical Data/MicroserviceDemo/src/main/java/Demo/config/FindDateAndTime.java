package Demo.config;

import java.time.LocalDateTime;

import org.springframework.stereotype.Component;


@Component
public class FindDateAndTime {

	
	public LocalDateTime dateAndTime(){
		
		LocalDateTime dateTime= LocalDateTime.now();
		
		return dateTime;
	}
	
}
