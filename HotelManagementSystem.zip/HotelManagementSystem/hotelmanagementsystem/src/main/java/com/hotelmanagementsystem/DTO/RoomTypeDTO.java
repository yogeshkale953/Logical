package com.hotelmanagementsystem.DTO;

public class RoomTypeDTO {

	
	
}
