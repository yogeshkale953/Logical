package com.hotelmanagementsystem.DTO;

import com.hotelmanagementsystem.entity.Customer;
import com.hotelmanagementsystem.entity.Room;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RoomBookDTO {

//	private Customer customer;
	private Room room;
	
	
}
