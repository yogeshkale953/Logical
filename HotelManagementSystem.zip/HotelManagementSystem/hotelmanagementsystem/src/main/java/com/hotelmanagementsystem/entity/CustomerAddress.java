package com.hotelmanagementsystem.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerAddress {
	private String primary_address;
	private String secondary_address;
}
