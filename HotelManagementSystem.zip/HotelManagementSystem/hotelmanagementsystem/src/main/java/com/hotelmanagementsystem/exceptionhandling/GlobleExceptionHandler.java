package com.hotelmanagementsystem.exceptionhandling;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobleExceptionHandler {

	@ExceptionHandler(value=CustomerIdNotFound.class)
	public void exeption(CustomerIdNotFound c) {
		
	}
	
	
}
