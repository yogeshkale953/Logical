package com.hotelmanagementsystem.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.apache.el.stream.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.hotelmanagementsystem.DTO.RoomBookDTO;
import com.hotelmanagementsystem.Utility.CancelRoomUtility;
import com.hotelmanagementsystem.Utility.RoomUtility;
import com.hotelmanagementsystem.entity.Room;
import com.hotelmanagementsystem.entity.RoomType;

@Service
public class BookRoomService {

	@Autowired
	RoomUtility r;

	@Autowired
	CancelRoomUtility cancelRoom;

	public List<Room> getAllAvailbaleRooms() {

//		RoomUtility r = new RoomUtility();

		return r.getAvailableRoomDetails();

	}

	public List<Room> bookRoom(Room room) throws Exception {

		return r.roomBookDetails(room);

	}

	public List<Room> getBookedRooms() {
		return r.getBookedRoom();
	}

	@Scheduled(cron = "0 * 18 * * ?")
	public void findCheckInDate() {

		LocalDate todays_date = LocalDate.now();
		System.out.println(todays_date + " todays date ");
		List<Room> rooms = r.getBookedRoom();
		for (Room r : rooms) {
			System.out.println("customer date is " + r.getCheckInDate());
			if (todays_date.equals(r.getCheckInDate())) {
				System.out.println("check-in date is approaching for Customer" + r.getCustomer().getCustomer_name());
			}
		}
	}

	public void cancelBooking(int roomId) {

		boolean validateID = cancelRoom.cancelRoomUtility(roomId);

		if (validateID == true) {
			r.cancelRoomBooking(roomId);
		} else {
			System.out.println("You can Cancel booking within 24hr only...");
		}

	}

	public void updateBooking(int roomId, RoomType roomType) {

		r.updateBooking(roomId,roomType);

	}

}
