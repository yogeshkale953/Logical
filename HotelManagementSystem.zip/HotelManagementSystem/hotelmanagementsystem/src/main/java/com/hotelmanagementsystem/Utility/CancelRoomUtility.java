package com.hotelmanagementsystem.Utility;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hotelmanagementsystem.entity.Room;

@Component
public class CancelRoomUtility {

	@Autowired
	RoomUtility r_utility;
	
	
	public boolean cancelRoomUtility(int roomId){
		
		LocalDate currentDate=LocalDate.now();
		
		Room room=r_utility.getRoomById(roomId);
		if(room.getCheckInDate().equals(currentDate)) {
			return true;
			}
		return false;
	}
}
