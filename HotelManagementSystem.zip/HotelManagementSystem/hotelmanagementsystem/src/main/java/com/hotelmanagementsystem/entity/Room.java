package com.hotelmanagementsystem.entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class Room {
 private int room_id;
 @JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
 private LocalDate checkInDate;
 @JsonFormat(shape=JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
 private LocalDate checkOutDate;
 private RoomType roomType;
 private Customer customer;

 
}

