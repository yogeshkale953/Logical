package com.hotelmanagementsystem.exceptionhandling;


public class RoomIDNotFound extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RoomIDNotFound(String msg){
		super(msg);
	}
}
