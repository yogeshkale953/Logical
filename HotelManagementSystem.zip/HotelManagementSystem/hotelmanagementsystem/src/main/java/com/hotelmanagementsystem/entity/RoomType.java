package com.hotelmanagementsystem.entity;

public enum RoomType {
	SpecialRoom, NormalRoom;

}
