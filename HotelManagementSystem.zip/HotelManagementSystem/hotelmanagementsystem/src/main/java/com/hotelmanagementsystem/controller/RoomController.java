package com.hotelmanagementsystem.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hotelmanagementsystem.DTO.RoomBookDTO;
import com.hotelmanagementsystem.entity.Room;
import com.hotelmanagementsystem.entity.RoomType;
import com.hotelmanagementsystem.service.BookRoomService;

@RestController
public class RoomController {

	Logger logger = LoggerFactory.getLogger(RoomController.class);

	@Autowired
	BookRoomService bookRoomService;

	@GetMapping("/getRoomDetails")
	public List<Room> getRoomDetails() {

		logger.info("inside getRoomDetails");
		return bookRoomService.getAllAvailbaleRooms();

	}
	
	@PostMapping("/bookRoom")
	public List<Room> bookRoom(@RequestBody Room room) throws Exception {

		
		
		System.out.println("In controller"+room.getCustomer());
		logger.info("inside bookRoom " +room);
		bookRoomService.bookRoom(room);
		return bookRoomService.getAllAvailbaleRooms();

	}
	@GetMapping("/getBookedRooms")
	public List<Room> getBookedRooms() {

		logger.info("inside getRoomDetails");
		return bookRoomService.getBookedRooms();

	}
	@DeleteMapping("/cancelBooking/{id}")
	public void cancelBooking(int roomId) {
		System.out.println(roomId);
		bookRoomService.cancelBooking(roomId);
		
	}
	@PutMapping("/updateBooking/{id}")
	public void updateBooking(@RequestBody RoomType r, @PathVariable int id) {
		
		System.out.println(id+" roomType "+r);
		bookRoomService.updateBooking(id,r);
		
	}
	
}
