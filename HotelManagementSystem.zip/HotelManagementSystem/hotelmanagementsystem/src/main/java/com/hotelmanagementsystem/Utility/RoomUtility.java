package com.hotelmanagementsystem.Utility;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hotelmanagementsystem.DTO.RoomBookDTO;
import com.hotelmanagementsystem.entity.Customer;
import com.hotelmanagementsystem.entity.Room;
import com.hotelmanagementsystem.entity.RoomType;
import com.hotelmanagementsystem.exceptionhandling.CustomerIdNotFound;
import com.hotelmanagementsystem.exceptionhandling.RoomIDNotFound;

@Component
public class RoomUtility {

	Logger logger = LoggerFactory.getLogger(RoomUtility.class);

	List<Room> bookedRooms = new ArrayList();

	public List<Room> getAvailableRoomDetails() {

		Room roomNo1 = new Room();

		roomNo1.setRoom_id(1);
		roomNo1.setRoomType(RoomType.SpecialRoom);

		Room roomNo2 = new Room();

		roomNo2.setRoom_id(2);
		roomNo2.setRoomType(RoomType.SpecialRoom);

		Room roomNo3 = new Room();

		roomNo3.setRoom_id(3);
		roomNo3.setRoomType(RoomType.NormalRoom);

		Room roomNo4 = new Room();

		roomNo4.setRoom_id(4);
		roomNo4.setRoomType(RoomType.NormalRoom);

		List<Room> availableRoom = List.of(roomNo1, roomNo2, roomNo3, roomNo4).stream()
				.filter(s -> Optional.ofNullable(s).isPresent()).collect(Collectors.toList());

		return availableRoom;

	}

	public List<Room> roomBookDetails(Room room) throws Exception {

//		Optional.ofNullable(room.getRoom().getCustomer().getCustomer_id())
//				.orElseThrow(() -> new CustomerIdNotFound("Customer ID Not Found"));
		int r_id = Optional.ofNullable(room.getRoom_id()).orElseThrow(() -> new RoomIDNotFound("Room ID Not Found"));

		System.out.println(room.getCheckInDate() + "in service " + room);
		Customer c = new Customer();
		c.setRoom(room);
		;
		bookedRooms.add(room);

		return bookedRooms;

	}

	public void saveRoomBookedInfo() {
		// TODO Auto-generated method stub

	}

	public List<Room> getBookedRoom() {

		return bookedRooms;

	}

	public Room getRoomById(int room_id) {
		Room tempRoom = null;
		for (Room room : bookedRooms) {
			if (room.getRoom_id() == room_id) {
				tempRoom = room;
			}

		}

		return tempRoom;
	}

	public void cancelRoomBooking(int roomId) {
		System.out.println("in cancel Room Booking");
		Room r = getRoomById(roomId);
		int index = bookedRooms.indexOf(r);
		System.out.println("Canceling Room Booking for " + r.getCustomer().getCustomer_name());
		bookedRooms.remove(index);
		System.out.println("Canceled Booking Successfully");

	}

	public void updateBooking(int roomId, RoomType roomType) {
		
		Room r = getRoomById(roomId);
//		r.setRoom_id(roomId);
		int index = bookedRooms.indexOf(r);
		System.out.println("index is="+index);
		Room room = bookedRooms.get(index);
		r.setCheckOutDate(room.getCheckInDate());
		r.setCheckInDate(room.getCheckInDate());
		r.setCustomer(room.getCustomer());
		r.setRoomType(roomType);
		
		bookedRooms.add(index, r);
		for(Room ro:bookedRooms) {
			System.out.println(ro.getRoomType()+"updatedROomType is");
		}
		

	}

}
